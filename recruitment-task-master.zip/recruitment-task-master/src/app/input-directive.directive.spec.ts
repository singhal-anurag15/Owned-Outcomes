import { InputDirectiveDirective } from './input-directive.directive';

describe('InputDirectiveDirective', () => {
  it('should create an instance', () => {
    const directive = new InputDirectiveDirective();
    expect(directive).toBeTruthy();
  });
});
