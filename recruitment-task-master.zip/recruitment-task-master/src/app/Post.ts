export class Posts{
public id: number;
public title: string;
public author:string;
}