import { Component, OnInit } from '@angular/core';
import { ApiService } from '../api.service';

@Component({
  selector: 'app-post-component',
  templateUrl: './post-component.component.html',
  styleUrls: ['./post-component.component.css']
})
export class PostComponentComponent implements OnInit {

  allPosts: Post[];
  constructor(private apiservice: ApiService) {


   }

  ngOnInit() {

    this.apiservice.getPosts().subscribe((posts) => {
      console.log(posts);
      this.allPosts = posts; 

    });
  }

}


interface Post{
  id: number,
  title: string,
  author: string
}